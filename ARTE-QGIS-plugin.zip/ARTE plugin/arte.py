import os
import time
import gc
import json
import numpy as np
import math
import urllib.request
from PIL import Image
from osgeo import gdal, osr
from qgis.core import *
from qgis.utils import iface
from qgis.gui import QgsMapToolExtent, QgsMapTool, QgsRubberBand
from qgis.PyQt.QtCore import QSize, pyqtSignal, Qt, QUrl
from qgis.PyQt.QtGui import QColor, QIcon, QDesktopServices
from qgis.PyQt.QtWidgets import (QApplication, QDialog, QFormLayout, QDoubleSpinBox,
								 QSpinBox, QDialogButtonBox, QVBoxLayout, QMessageBox, QAction,
								 QLineEdit, QHBoxLayout, QPushButton, QFileDialog, QProgressDialog, QMenu,
								 QComboBox, QToolTip, QCheckBox, QLabel)

# --- Version & GitHub Info ---
VERSION = "1.0.0"
GITHUB_USER = "Rendszerguru"
GITHUB_REPO = "ARTE-QGIS-plugin"

if hasattr(QMessageBox, 'StandardButton'):
	QM_Yes = QMessageBox.StandardButton.Yes
	QM_No = QMessageBox.StandardButton.No
	QM_Ok = QMessageBox.StandardButton.Ok
else:
	QM_Yes = QMessageBox.Yes
	QM_No = QMessageBox.No
	QM_Ok = QMessageBox.Ok

if hasattr(Qt, 'MouseButton'):
	Qt_LeftButton = Qt.MouseButton.LeftButton
	Qt_RightButton = Qt.MouseButton.RightButton
else:
	Qt_LeftButton = Qt.LeftButton
	Qt_RightButton = Qt.RightButton

if hasattr(Qt, 'CursorShape'):
	Cur_Cross = Qt.CursorShape.CrossCursor
	Cur_SizeAll = Qt.CursorShape.SizeAllCursor
	Cur_SizeHor = Qt.CursorShape.SizeHorCursor
	Cur_SizeVer = Qt.CursorShape.SizeVerCursor
	Cur_SizeFDiag = Qt.CursorShape.SizeFDiagCursor
	Cur_SizeBDiag = Qt.CursorShape.SizeBDiagCursor
	Cur_Arrow = Qt.CursorShape.ArrowCursor
else:
	Cur_Cross = Qt.CrossCursor
	Cur_SizeAll = Qt.SizeAllCursor
	Cur_SizeHor = Qt.SizeHorCursor
	Cur_SizeVer = Qt.SizeVerCursor
	Cur_SizeFDiag = Qt.SizeFDiagCursor
	Cur_SizeBDiag = Qt.SizeBDiagCursor
	Cur_Arrow = Qt.ArrowCursor

if hasattr(Qt, 'Key'):
	Key_Enter = Qt.Key.Key_Enter
	Key_Return = Qt.Key.Key_Return
else:
	Key_Enter = Qt.Key_Enter
	Key_Return = Qt.Key_Return

if hasattr(Qt, 'AlignmentFlag'):
	Qt_AlignCenter = Qt.AlignmentFlag.AlignCenter
else:
	Qt_AlignCenter = Qt.AlignCenter

# --- Map Tool classes ---
class ArmaAdvancedMapTool(QgsMapTool):
	extentSelected = pyqtSignal(object)

	def __init__(self, canvas, dialog):
		super().__init__(canvas)
		self.canvas = canvas
		self.dialog = dialog

		self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
		self.rubber_band.setColor(QColor(255, 0, 0, 60))
		self.rubber_band.setStrokeColor(QColor(255, 0, 0, 255))

		self.rect = None
		self.drag_mode = None
		self.drag_start_pos = None
		self.drag_start_rect = None

		self.init_initial_extent()

	def init_initial_extent(self):
		center_x = self.dialog.sb_x.value()
		center_y = self.dialog.sb_y.value()
		size_w = self.dialog.sb_size_w.value()
		size_h = self.dialog.sb_size_h.value()

		crs_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
		canvas_crs = self.canvas.mapSettings().destinationCrs()
		transform = QgsCoordinateTransform(crs_4326, canvas_crs, QgsProject.instance().transformContext())

		try:
			pt_canvas = transform.transform(QgsPointXY(center_x, center_y))
		except:
			return

		lat_rad = math.radians(center_y)
		scale_factor = 1.0 / math.cos(lat_rad)
		size_w_mu = size_w * scale_factor
		size_h_mu = size_h * scale_factor
		half_w = size_w_mu / 2.0
		half_h = size_h_mu / 2.0

		self.rect = QgsRectangle(pt_canvas.x() - half_w, pt_canvas.y() - half_h, pt_canvas.x() + half_w, pt_canvas.y() + half_h)
		self.update_rubberband()

	def update_rubberband(self):
		if self.rect:
			self.rubber_band.setToGeometry(QgsGeometry.fromRect(self.rect), None)

	def get_drag_mode(self, pos):
		if not self.rect: return 'new'

		pt = self.toMapCoordinates(pos)
		tol = self.canvas.mapUnitsPerPixel() * 15

		left = abs(pt.x() - self.rect.xMinimum()) < tol
		right = abs(pt.x() - self.rect.xMaximum()) < tol
		top = abs(pt.y() - self.rect.yMaximum()) < tol
		bottom = abs(pt.y() - self.rect.yMinimum()) < tol

		if left and top: return 'resize_tl'
		if right and top: return 'resize_tr'
		if left and bottom: return 'resize_bl'
		if right and bottom: return 'resize_br'
		if left: return 'resize_l'
		if right: return 'resize_r'
		if top: return 'resize_t'
		if bottom: return 'resize_b'

		if self.rect.contains(pt):
			return 'move'

		return 'new'

	def show_size_tooltip(self, pos):
		if self.rect:
			try:
				center_pt = self.rect.center()
				crs_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
				canvas_crs = self.canvas.mapSettings().destinationCrs()
				transform_to_4326 = QgsCoordinateTransform(canvas_crs, crs_4326, QgsProject.instance().transformContext())

				center_4326 = transform_to_4326.transform(center_pt)
				lat_rad = math.radians(center_4326.y())
				scale_factor = 1.0 / math.cos(lat_rad)

				real_w = int(self.rect.width() / scale_factor)
				real_h = int(self.rect.height() / scale_factor)

				global_pos = self.canvas.mapToGlobal(pos)
				QToolTip.showText(global_pos, f"Keret: {real_w}m x {real_h}m")
			except:
				pass

	def canvasPressEvent(self, e):
		if e.button() == Qt_LeftButton:
			self.drag_mode = self.get_drag_mode(e.pos())
			self.drag_start_pos = self.toMapCoordinates(e.pos())
			if self.rect:
				self.drag_start_rect = QgsRectangle(self.rect)
			else:
				self.drag_start_rect = None

	def canvasMoveEvent(self, e):
		if not (e.buttons() & Qt_LeftButton) or not self.drag_start_pos:
			mode = self.get_drag_mode(e.pos())
			if mode in ('resize_tl', 'resize_br'):
				self.canvas.setCursor(Cur_SizeFDiag)
			elif mode in ('resize_tr', 'resize_bl'):
				self.canvas.setCursor(Cur_SizeBDiag)
			elif mode in ('resize_l', 'resize_r'):
				self.canvas.setCursor(Cur_SizeHor)
			elif mode in ('resize_t', 'resize_b'):
				self.canvas.setCursor(Cur_SizeVer)
			elif mode == 'move':
				self.canvas.setCursor(Cur_SizeAll)
			else:
				self.canvas.setCursor(Cur_Cross)

			if mode != 'new':
				self.show_size_tooltip(e.pos())
			else:
				QToolTip.hideText()
			return

		current_pt = self.toMapCoordinates(e.pos())
		dx = current_pt.x() - self.drag_start_pos.x()
		dy = current_pt.y() - self.drag_start_pos.y()

		is_square_locked = self.dialog.cb_size_lock.isChecked()

		if self.drag_mode == 'new':
			if is_square_locked:
				side = max(abs(dx), abs(dy))
				sign_x = 1 if dx > 0 else -1
				sign_y = 1 if dy > 0 else -1
				sq_pt = QgsPointXY(self.drag_start_pos.x() + side * sign_x, self.drag_start_pos.y() + side * sign_y)
				self.rect = QgsRectangle(self.drag_start_pos, sq_pt)
			else:
				self.rect = QgsRectangle(self.drag_start_pos, current_pt)

		elif self.drag_mode == 'move' and self.drag_start_rect:
			self.rect = QgsRectangle(
				self.drag_start_rect.xMinimum() + dx,
				self.drag_start_rect.yMinimum() + dy,
				self.drag_start_rect.xMaximum() + dx,
				self.drag_start_rect.yMaximum() + dy
			)
		elif self.drag_start_rect:
			xmin = self.drag_start_rect.xMinimum()
			xmax = self.drag_start_rect.xMaximum()
			ymin = self.drag_start_rect.yMinimum()
			ymax = self.drag_start_rect.yMaximum()

			if 'l' in self.drag_mode: xmin += dx
			if 'r' in self.drag_mode: xmax += dx
			if 'b' in self.drag_mode: ymin += dy
			if 't' in self.drag_mode: ymax += dy

			if is_square_locked:
				w = abs(xmax - xmin)
				h = abs(ymax - ymin)
				side = max(w, h)

				if 'l' in self.drag_mode: xmin = xmax - side
				elif 'r' in self.drag_mode: xmax = xmin + side
				else:
					cx = (xmin + xmax) / 2
					xmin, xmax = cx - side/2, cx + side/2

				if 'b' in self.drag_mode: ymin = ymax - side
				elif 't' in self.drag_mode: ymax = ymin + side
				else:
					cy = (ymin + ymax) / 2
					ymin, ymax = cy - side/2, cy + side/2

			self.rect = QgsRectangle(min(xmin, xmax), min(ymin, ymax), max(xmin, xmax), max(ymin, ymax))

		self.update_rubberband()
		self.show_size_tooltip(e.pos())

	def canvasReleaseEvent(self, e):
		if e.button() == Qt_LeftButton:
			self.drag_mode = None
			self.drag_start_pos = None
		elif e.button() == Qt_RightButton:
			if self.rect:
				self.extentSelected.emit(self.rect)

	def keyPressEvent(self, e):
		if e.key() in (Key_Enter, Key_Return):
			if self.rect:
				self.extentSelected.emit(self.rect)

	def deactivate(self):
		self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)
		self.canvas.setCursor(Cur_Arrow)
		QToolTip.hideText()
		super().deactivate()

# --- Input Dialog Window ---
class CombinedArmaInputDialog(QDialog):
	def __init__(self, parent=None):
		super().__init__(parent if parent else iface.mainWindow())
		self.setWindowTitle(f"ARTE - Arma Reforger Terrain Exporter (v{VERSION})")
		self.resize(520, 560)

		plugin_dir = os.path.dirname(__file__)
		icon_path = os.path.join(plugin_dir, 'icon.png')
		if os.path.exists(icon_path):
			self.setWindowIcon(QIcon(icon_path))

		layout = QVBoxLayout(self)
		self.form_layout = QFormLayout()

		self.btn_load_map = QPushButton("1. Load Satellite Preview")
		self.btn_load_map.clicked.connect(self.load_preview_map)

		self.btn_select_canvas = QPushButton("2. Select Extent on Map")
		self.btn_select_canvas.setStyleSheet("font-weight: bold;")

		existing_layers = QgsProject.instance().mapLayers().values()
		has_satellite_preview = any("Google Satellite" in layer.name() or "Preview" in layer.name() for layer in existing_layers)

		if has_satellite_preview:
			self.btn_select_canvas.setEnabled(True)
			self.btn_select_canvas.setToolTip("")
		else:
			self.btn_select_canvas.setEnabled(False)
			self.btn_select_canvas.setToolTip("Load the satellite map using button 1 first.")

		self.btn_select_canvas.clicked.connect(self.start_canvas_selection)

		map_layout = QHBoxLayout()
		map_layout.addWidget(self.btn_load_map)
		map_layout.addWidget(self.btn_select_canvas)

		settings = QgsSettings()
		saved_x = float(settings.value("ArmaReforgerTools/center_x", 15.256576))
		saved_y = float(settings.value("ArmaReforgerTools/center_y", 46.041305))
		saved_size_w = int(settings.value("ArmaReforgerTools/size_w", 12100))
		saved_size_h = int(settings.value("ArmaReforgerTools/size_h", 12100))
		saved_size_lock = settings.value("ArmaReforgerTools/size_lock", True, type=bool)

		saved_res_w = int(settings.value("ArmaReforgerTools/res_w", 4096))
		saved_res_h = int(settings.value("ArmaReforgerTools/res_h", 4096))
		saved_res_lock = settings.value("ArmaReforgerTools/res_lock", True, type=bool)

		saved_sat_res_w = int(settings.value("ArmaReforgerTools/sat_res_w", 4096))
		saved_sat_res_h = int(settings.value("ArmaReforgerTools/sat_res_h", 4096))
		saved_sat_res_lock = settings.value("ArmaReforgerTools/sat_res_lock", True, type=bool)

		saved_source = int(settings.value("ArmaReforgerTools/source", 0))
		saved_ot_type = settings.value("ArmaReforgerTools/ot_dem_type", "COP30")
		saved_format = int(settings.value("ArmaReforgerTools/format", 0))
		saved_path = settings.value("ArmaReforgerTools/output_path", "C:/QGIS/ArmaTerrainExport")
		saved_burn = settings.value("ArmaReforgerTools/burn_terrain", False, type=bool)
		saved_multiplier = float(settings.value("ArmaReforgerTools/engineer_multiplier", 1.15))

		self.sb_x = QDoubleSpinBox()
		self.sb_x.setRange(-180.0, 180.0)
		self.sb_x.setDecimals(6)
		self.sb_x.setValue(saved_x)
		self.sb_x.setSingleStep(0.01)

		self.sb_y = QDoubleSpinBox()
		self.sb_y.setRange(-90.0, 90.0)
		self.sb_y.setDecimals(6)
		self.sb_y.setValue(saved_y)
		self.sb_y.setSingleStep(0.01)

		self.sb_size_w = QSpinBox()
		self.sb_size_w.setRange(1, 1000000)
		self.sb_size_w.setValue(saved_size_w)
		self.sb_size_w.setSingleStep(100)

		self.sb_size_h = QSpinBox()
		self.sb_size_h.setRange(1, 1000000)
		self.sb_size_h.setValue(saved_size_h)
		self.sb_size_h.setSingleStep(100)

		self.cb_size_lock = QCheckBox()
		self.cb_size_lock.setToolTip("Lock Aspect Ratio to 1:1 (Square Selection / Size)")
		self.cb_size_lock.setChecked(saved_size_lock)
		self.cb_size_lock.stateChanged.connect(self.on_size_lock_toggled)

		self.sb_size_w.valueChanged.connect(self.on_size_w_changed)
		self.sb_size_h.valueChanged.connect(self.on_size_h_changed)

		size_layout = QHBoxLayout()
		size_layout.addWidget(self.sb_size_w)
		size_layout.addWidget(self.cb_size_lock)
		size_layout.addWidget(self.sb_size_h)

		# --- Heightmap Resolution ---
		self.sb_res_w = QSpinBox()
		self.sb_res_w.setRange(128, 32768)
		self.sb_res_w.setValue(saved_res_w)
		self.sb_res_w.setSingleStep(128)

		self.sb_res_h = QSpinBox()
		self.sb_res_h.setRange(128, 32768)
		self.sb_res_h.setValue(saved_res_h)
		self.sb_res_h.setSingleStep(128)

		self.cb_square_lock = QCheckBox()
		self.cb_square_lock.setToolTip("Lock Aspect Ratio to 1:1 (Heightmap Resolution)")
		self.cb_square_lock.setChecked(saved_res_lock)
		self.cb_square_lock.stateChanged.connect(self.on_lock_toggled)

		self.sb_res_w.valueChanged.connect(self.on_res_w_changed)
		self.sb_res_h.valueChanged.connect(self.on_res_h_changed)

		res_layout = QHBoxLayout()
		res_layout.addWidget(self.sb_res_w)
		res_layout.addWidget(self.cb_square_lock)
		res_layout.addWidget(self.sb_res_h)

		# --- Satellite Resolution ---
		self.sb_sat_res_w = QSpinBox()
		self.sb_sat_res_w.setRange(128, 65536)
		self.sb_sat_res_w.setValue(saved_sat_res_w)
		self.sb_sat_res_w.setSingleStep(128)

		self.sb_sat_res_h = QSpinBox()
		self.sb_sat_res_h.setRange(128, 65536)
		self.sb_sat_res_h.setValue(saved_sat_res_h)
		self.sb_sat_res_h.setSingleStep(128)

		self.cb_sat_square_lock = QCheckBox()
		self.cb_sat_square_lock.setToolTip("Lock Aspect Ratio to 1:1 (Satellite Resolution)")
		self.cb_sat_square_lock.setChecked(saved_sat_res_lock)
		self.cb_sat_square_lock.stateChanged.connect(self.on_sat_lock_toggled)

		self.sb_sat_res_w.valueChanged.connect(self.on_sat_res_w_changed)
		self.sb_sat_res_h.valueChanged.connect(self.on_sat_res_h_changed)

		sat_res_layout = QHBoxLayout()
		sat_res_layout.addWidget(self.sb_sat_res_w)
		sat_res_layout.addWidget(self.cb_sat_square_lock)
		sat_res_layout.addWidget(self.sb_sat_res_h)


		self.mapbox_key = settings.value("ArmaReforgerTools/mapbox_api_key", "")
		self.ot_key = settings.value("ArmaReforgerTools/ot_api_key", "")

		self.cb_source = QComboBox()
		self.cb_source.addItems([
			"AWS Terrarium (Free, Global 30m, Enhanced Smooth)",
			"Mapbox Terrain-RGB (API Key Required, Higher Detail)",
			"LiDAR (BEV / OpenTopography) - API Key Required"
		])
		self.cb_source.setCurrentIndex(saved_source)
		self.cb_source.currentIndexChanged.connect(self.on_source_changed)

		self.lbl_ot_type = QLabel("OpenTopo Dataset:")
		self.cb_ot_type = QComboBox()
		self.cb_ot_type.addItem("COP30 (Best Global - Clean & Modern)", "COP30")
		self.cb_ot_type.addItem("AW3D30 (Good Global - Detailed)", "AW3D30")
		self.cb_ot_type.addItem("EU_DTM (Best for Europe - Bare Earth)", "EU_DTM")
		self.cb_ot_type.addItem("NASADEM (Good Global Alternative)", "NASADEM")
		self.cb_ot_type.addItem("SRTMGL1 (Classic NASA DEM)", "SRTMGL1")

		idx_ot = self.cb_ot_type.findData(saved_ot_type)

		if idx_ot != -1:
			self.cb_ot_type.setCurrentIndex(idx_ot)

		self.lbl_ot_type.hide()
		self.cb_ot_type.hide()

		self.lbl_apikey = QLabel("API Key:")
		self.le_apikey = QLineEdit()
		if hasattr(QLineEdit, 'EchoMode'):
			self.le_apikey.setEchoMode(QLineEdit.EchoMode.Password)
		else:
			self.le_apikey.setEchoMode(QLineEdit.Password)
		self.le_apikey.textChanged.connect(self.on_api_key_edited)

		self.cb_show_key = QCheckBox("Show")
		self.cb_show_key.stateChanged.connect(self.toggle_password_visibility)

		api_layout = QHBoxLayout()
		api_layout.addWidget(self.le_apikey)
		api_layout.addWidget(self.cb_show_key)

		self.cb_format = QComboBox()
		self.cb_format.addItems([
			"16-bit PNG + TXT (Recommended for Enfusion)",
			"Esri ASCII Grid (.asc)",
			"GeoTIFF (.tif) - Raw Float32 Elevation"
		])
		self.cb_format.setCurrentIndex(saved_format)

		self.cb_burn_terrain = QCheckBox("Smooth Roads & Carve Riverbeds (OSM)")
		self.cb_burn_terrain.setChecked(saved_burn)

		self.sb_multiplier = QDoubleSpinBox()
		self.sb_multiplier.setRange(1.0, 1.5)
		self.sb_multiplier.setDecimals(2)
		self.sb_multiplier.setValue(saved_multiplier)
		self.sb_multiplier.setSingleStep(0.05)
		self.sb_multiplier.setSuffix("x")
		self.sb_multiplier.setToolTip("Compensate for Enfusion smooth tool by over-widening roads/rails.")

		self.le_path = QLineEdit(saved_path)
		browse_layout = QHBoxLayout()
		browse_layout.addWidget(self.le_path)
		btn_browse = QPushButton("Browse")
		btn_browse.clicked.connect(self.browse_path)
		browse_layout.addWidget(btn_browse)

		self.form_layout.addRow("Map Tools:", map_layout)
		self.form_layout.addRow("Center X (Longitude):", self.sb_x)
		self.form_layout.addRow("Center Y (Latitude):", self.sb_y)
		self.form_layout.addRow("Size (meters):", size_layout)
		self.form_layout.addRow("Heightmap Res (px):", res_layout)
		self.form_layout.addRow("Satellite Res (px):", sat_res_layout)
		self.form_layout.addRow("Elevation Data Source:", self.cb_source)
		self.form_layout.addRow(self.lbl_ot_type, self.cb_ot_type)
		self.form_layout.addRow(self.lbl_apikey, api_layout)
		self.form_layout.addRow("Terrain Engineering:", self.cb_burn_terrain)
		self.form_layout.addRow("Engineering Width Multiplier:", self.sb_multiplier)
		self.form_layout.addRow("Heightmap Format:", self.cb_format)
		self.form_layout.addRow("Output Directory:", browse_layout)

		btn_save_layout = QHBoxLayout()
		self.btn_save_only = QPushButton("Save Settings")
		self.btn_save_only.clicked.connect(self.save_only)

		self.btn_reset = QPushButton("Reset to Defaults")
		self.btn_reset.clicked.connect(self.reset_settings)

		btn_save_layout.addWidget(self.btn_save_only)
		btn_save_layout.addWidget(self.btn_reset)
		self.form_layout.addRow("", btn_save_layout)

		layout.addLayout(self.form_layout)

		if hasattr(QDialogButtonBox, 'StandardButton'):
			ok_btn = QDialogButtonBox.StandardButton.Ok
			cancel_btn = QDialogButtonBox.StandardButton.Cancel
		else:
			ok_btn = QDialogButtonBox.Ok
			cancel_btn = QDialogButtonBox.Cancel

		buttons = QDialogButtonBox(ok_btn | cancel_btn)
		buttons.accepted.connect(self.save_and_accept)
		buttons.rejected.connect(self.save_and_reject)
		layout.addWidget(buttons)
		self.setLayout(layout)

		self.on_source_changed(self.cb_source.currentIndex())

	def save_settings(self):
		settings = QgsSettings()
		settings.setValue("ArmaReforgerTools/center_x", self.sb_x.value())
		settings.setValue("ArmaReforgerTools/center_y", self.sb_y.value())
		settings.setValue("ArmaReforgerTools/size_w", self.sb_size_w.value())
		settings.setValue("ArmaReforgerTools/size_h", self.sb_size_h.value())
		settings.setValue("ArmaReforgerTools/size_lock", self.cb_size_lock.isChecked())

		settings.setValue("ArmaReforgerTools/res_w", self.sb_res_w.value())
		settings.setValue("ArmaReforgerTools/res_h", self.sb_res_h.value())
		settings.setValue("ArmaReforgerTools/res_lock", self.cb_square_lock.isChecked())

		settings.setValue("ArmaReforgerTools/sat_res_w", self.sb_sat_res_w.value())
		settings.setValue("ArmaReforgerTools/sat_res_h", self.sb_sat_res_h.value())
		settings.setValue("ArmaReforgerTools/sat_res_lock", self.cb_sat_square_lock.isChecked())

		settings.setValue("ArmaReforgerTools/source", self.cb_source.currentIndex())
		settings.setValue("ArmaReforgerTools/ot_dem_type", self.cb_ot_type.currentData())
		settings.setValue("ArmaReforgerTools/format", self.cb_format.currentIndex())
		settings.setValue("ArmaReforgerTools/burn_terrain", self.cb_burn_terrain.isChecked())
		settings.setValue("ArmaReforgerTools/engineer_multiplier", self.sb_multiplier.value())
		settings.setValue("ArmaReforgerTools/output_path", self.le_path.text())

	def save_only(self):
		self.save_settings()
		iface.messageBar().pushMessage("Settings", "Settings saved successfully.", level=Qgis.Success, duration=3)

	def reset_settings(self):
		self.sb_x.setValue(15.256576)
		self.sb_y.setValue(46.041305)
		self.sb_size_w.setValue(12100)
		self.sb_size_h.setValue(12100)
		self.cb_size_lock.setChecked(True)

		self.sb_res_w.setValue(4096)
		self.sb_res_h.setValue(4096)
		self.cb_square_lock.setChecked(True)

		self.sb_sat_res_w.setValue(4096)
		self.sb_sat_res_h.setValue(4096)
		self.cb_sat_square_lock.setChecked(True)

		self.cb_source.setCurrentIndex(0)
		self.cb_format.setCurrentIndex(0)
		self.cb_burn_terrain.setChecked(False)
		self.sb_multiplier.setValue(1.10)
		self.le_path.setText("C:/QGIS/ArmaTerrainExport")
		iface.messageBar().pushMessage("Settings", "Reset to default values.", level=Qgis.Info, duration=3)

	def save_and_accept(self):
		self.save_settings()
		self.accept()

	def save_and_reject(self):
		self.save_settings()
		self.reject()

	def on_api_key_edited(self, text):
		idx = self.cb_source.currentIndex()
		if idx == 1:
			self.mapbox_key = text
		elif idx == 2:
			self.ot_key = text

	def on_source_changed(self, index):
		if index == 1:
			self.le_apikey.setText(self.mapbox_key)
			self.lbl_apikey.setText("Mapbox API Key:")
			self.le_apikey.setPlaceholderText("Paste Mapbox API key here")
			self.le_apikey.show()
			self.cb_show_key.show()
			self.lbl_apikey.show()
			self.lbl_ot_type.hide()
			self.cb_ot_type.hide()
		elif index == 2:
			self.le_apikey.setText(self.ot_key)
			self.lbl_apikey.setText("OpenTopo API Key:")
			self.le_apikey.setPlaceholderText("Paste OpenTopography API key here")
			self.le_apikey.show()
			self.cb_show_key.show()
			self.lbl_apikey.show()
			self.lbl_ot_type.show()
			self.cb_ot_type.show()
		else:
			self.le_apikey.hide()
			self.cb_show_key.hide()
			self.lbl_apikey.hide()
			self.lbl_ot_type.hide()
			self.cb_ot_type.hide()

	def toggle_password_visibility(self, state=None):
		use_normal = QLineEdit.EchoMode.Normal if hasattr(QLineEdit, 'EchoMode') else QLineEdit.Normal
		use_password = QLineEdit.EchoMode.Password if hasattr(QLineEdit, 'EchoMode') else QLineEdit.Password

		if self.cb_show_key.isChecked():
			self.le_apikey.setEchoMode(use_normal)
		else:
			self.le_apikey.setEchoMode(use_password)

	def on_size_w_changed(self, val):
		if self.cb_size_lock.isChecked():
			self.sb_size_h.blockSignals(True)
			self.sb_size_h.setValue(val)
			self.sb_size_h.blockSignals(False)

	def on_size_h_changed(self, val):
		if self.cb_size_lock.isChecked():
			self.sb_size_w.blockSignals(True)
			self.sb_size_w.setValue(val)
			self.sb_size_w.blockSignals(False)

	def on_size_lock_toggled(self, state):
		if self.cb_size_lock.isChecked():
			self.sb_size_h.setValue(self.sb_size_w.value())

	def on_res_w_changed(self, val):
		if self.cb_square_lock.isChecked():
			self.sb_res_h.blockSignals(True)
			self.sb_res_h.setValue(val)
			self.sb_res_h.blockSignals(False)

	def on_res_h_changed(self, val):
		if self.cb_square_lock.isChecked():
			self.sb_res_w.blockSignals(True)
			self.sb_res_w.setValue(val)
			self.sb_res_w.blockSignals(False)

	def on_lock_toggled(self, state):
		if self.cb_square_lock.isChecked():
			self.sb_res_h.setValue(self.sb_res_w.value())

	def on_sat_res_w_changed(self, val):
		if self.cb_sat_square_lock.isChecked():
			self.sb_sat_res_h.blockSignals(True)
			self.sb_sat_res_h.setValue(val)
			self.sb_sat_res_h.blockSignals(False)

	def on_sat_res_h_changed(self, val):
		if self.cb_sat_square_lock.isChecked():
			self.sb_sat_res_w.blockSignals(True)
			self.sb_sat_res_w.setValue(val)
			self.sb_sat_res_w.blockSignals(False)

	def on_sat_lock_toggled(self, state):
		if self.cb_sat_square_lock.isChecked():
			self.sb_sat_res_h.setValue(self.sb_sat_res_w.value())


	def browse_path(self):
		directory = QFileDialog.getExistingDirectory(self, "Select Output Directory")
		if directory:
			self.le_path.setText(directory)

	def load_preview_map(self):
		canvas = iface.mapCanvas()

		crs_3857 = QgsCoordinateReferenceSystem("EPSG:3857")
		QgsProject.instance().setCrs(crs_3857)

		layer_name = "Google Satellite Preview"
		layers = QgsProject.instance().mapLayersByName(layer_name)
		if not layers:
			uri = "type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=20&zmin=0"
			rlayer = QgsRasterLayer(uri, layer_name, "wms")
			if rlayer.isValid():
				QgsProject.instance().addMapLayer(rlayer)

		x_center = self.sb_x.value()
		y_center = self.sb_y.value()
		size_meters = max(self.sb_size_w.value(), self.sb_size_h.value())

		source_crs = QgsCoordinateReferenceSystem("EPSG:4326")
		transform = QgsCoordinateTransform(source_crs, crs_3857, QgsProject.instance().transformContext())

		try:
			pt = transform.transform(QgsPointXY(x_center, y_center))
			half = (size_meters * 1.5) / 2
			rect = QgsRectangle(pt.x() - half, pt.y() - half, pt.x() + half, pt.y() + half)
			canvas.setExtent(rect)
			canvas.refresh()

			self.btn_select_canvas.setEnabled(True)
			self.btn_select_canvas.setToolTip("")

			iface.messageBar().pushMessage("Terrain Export", "Satellite map loaded and zoomed to coordinates.", level=Qgis.Success, duration=3)
		except Exception as e:
			iface.messageBar().pushMessage("Terrain Export", f"Could not zoom: {e}", level=Qgis.Warning, duration=3)

	def start_canvas_selection(self):
		crs_3857 = QgsCoordinateReferenceSystem("EPSG:3857")
		if QgsProject.instance().crs() != crs_3857:
			QgsProject.instance().setCrs(crs_3857)

		self.canvas = iface.mapCanvas()

		x_center = self.sb_x.value()
		y_center = self.sb_y.value()
		size_meters = max(self.sb_size_w.value(), self.sb_size_h.value())

		source_crs = QgsCoordinateReferenceSystem("EPSG:4326")
		transform = QgsCoordinateTransform(source_crs, crs_3857, QgsProject.instance().transformContext())

		try:
			pt = transform.transform(QgsPointXY(x_center, y_center))
			half = (size_meters * 1.5) / 2
			rect = QgsRectangle(pt.x() - half, pt.y() - half, pt.x() + half, pt.y() + half)
			self.canvas.setExtent(rect)
			self.canvas.refresh()
		except Exception as e:
			pass

		self.hide()

		self.tool = ArmaAdvancedMapTool(self.canvas, self)
		self.tool.extentSelected.connect(self.on_extent_drawn)
		self.canvas.setMapTool(self.tool)

		iface.messageBar().pushMessage("Terrain Export", "The red frame shows the current selection. You can move or resize it, then RIGHT-CLICK or press ENTER to finish!", level=Qgis.Info, duration=8)

	def on_extent_drawn(self, extent):
		self.canvas.unsetMapTool(self.tool)
		self.show()

		canvas_crs = self.canvas.mapSettings().destinationCrs()
		crs_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
		crs_3857 = QgsCoordinateReferenceSystem("EPSG:3857")

		transform_to_4326 = QgsCoordinateTransform(canvas_crs, crs_4326, QgsProject.instance().transformContext())
		transform_to_3857 = QgsCoordinateTransform(canvas_crs, crs_3857, QgsProject.instance().transformContext())

		geom = QgsGeometry.fromRect(extent)

		geom_4326 = QgsGeometry(geom)
		geom_4326.transform(transform_to_4326)
		center = geom_4326.boundingBox().center()

		self.sb_x.setValue(center.x())
		self.sb_y.setValue(center.y())

		geom_3857 = QgsGeometry(geom)
		geom_3857.transform(transform_to_3857)
		box_3857 = geom_3857.boundingBox()

		lat_rad = math.radians(center.y())
		scale_factor = 1.0 / math.cos(lat_rad)
		base_size_w = box_3857.width() / scale_factor
		base_size_h = box_3857.height() / scale_factor

		self.sb_size_w.setValue(int(base_size_w))
		self.sb_size_h.setValue(int(base_size_h))
		iface.messageBar().pushMessage("Terrain Export", "Coordinates and size updated from map selection.", level=Qgis.Success, duration=3)

# =========================================================================
# TERRAIN ENGINEERING (WITH DEBUG LOGGING)
# =========================================================================
class TerrainEngineer:
	def __init__(self, iface):
		self.iface = iface

	def run(self, output_tif, output_dir, timestamp, xmin, ymin, xmax, ymax,
			resolution_w, resolution_h, target_crs, source_crs, context, pixel_size, step_callback, engineer_multiplier=1.15):

		created_temp_files = []
		log_path = os.path.join(output_dir, f"engineer_debug_{timestamp}.txt")

		def debug_log(message):
			from qgis.core import QgsMessageLog, Qgis
			timestamp_str = time.strftime('%H:%M:%S')
			full_msg = f"[{timestamp_str}] {message}"
			QgsMessageLog.logMessage(full_msg, "ArmaTerrainExport", Qgis.Info)
			with open(log_path, "a", encoding="utf-8") as f:
				f.write(full_msg + "\n")

		try:
			import processing
			from qgis.core import QgsVectorLayer, QgsCoordinateTransform, QgsPointXY, QgsRectangle
			from scipy.ndimage import distance_transform_edt, gaussian_filter

			debug_log("--- TERRAIN ENGINEER STARTED ---")
			debug_log(f"Resolution: {resolution_w}x{resolution_h}, Pixel size: {pixel_size:.2f}m")
			debug_log(f"Width Multiplier: {engineer_multiplier}x")

			step_callback(81, "Downloading OSM Engineering Vectors...")

			transform_to_4326_burn = QgsCoordinateTransform(target_crs, source_crs, context)
			pt_min_burn = transform_to_4326_burn.transform(QgsPointXY(xmin, ymin))
			pt_max_burn = transform_to_4326_burn.transform(QgsPointXY(xmax, ymax))

			south_b = min(pt_min_burn.y(), pt_max_burn.y())
			north_b = max(pt_min_burn.y(), pt_max_burn.y())
			west_b = min(pt_min_burn.x(), pt_max_burn.x())
			east_b = max(pt_min_burn.x(), pt_max_burn.x())

			overpass_urls = [
				"https://overpass-api.de/api/interpreter",
				"https://overpass.kumi.systems/api/interpreter",
				"https://lz4.overpass-api.de/api/interpreter"
			]

			overpass_query = f"""
			[out:json][timeout:120];
			(
			 way["highway"]({south_b},{west_b},{north_b},{east_b});
			 way["railway"]({south_b},{west_b},{north_b},{east_b});
			 way["waterway"]({south_b},{west_b},{north_b},{east_b});
			);
			(._;>;);
			out geom;
			"""

			debug_log("Fetching OSM data from Overpass API (with fallback endpoints)...")

			temp_geojson = os.path.join(output_dir, f"temp_osm_{timestamp}.geojson")
			created_temp_files.append(temp_geojson)

			osm_data = None
			last_error = None

			for url in overpass_urls:
				try:
					debug_log(f"Trying: {url}")

					req = urllib.request.Request(
						url,
						data=overpass_query.encode('utf-8'),
						headers={
							'User-Agent': 'QGIS-Arma-Plugin/1.0',
							'Content-Type': 'application/x-www-form-urlencoded'
						}
					)

					with urllib.request.urlopen(req, timeout=90) as response:
						osm_data = response.read()

					if osm_data and len(osm_data) > 200:
						debug_log(f"SUCCESS: Data received from {url}")
						break

				except Exception as e:
					last_error = e
					debug_log(f"FAILED: {url} -> {e}")

			if osm_data is None:
				debug_log(f"CRITICAL: All Overpass endpoints failed: {last_error}")
				return

			try:
				data = json.loads(osm_data)
				features = []

				for el in data.get("elements", []):
					if el.get("type") == "way" and "geometry" in el:
						coords = [(p["lon"], p["lat"]) for p in el["geometry"]]
						features.append({
							"type": "Feature",
							"geometry": {
								"type": "LineString",
								"coordinates": coords
							},
							"properties": el.get("tags", {})
						})

				geojson = {
					"type": "FeatureCollection",
					"features": features
				}

				with open(temp_geojson, 'w', encoding='utf-8') as f:
					json.dump(geojson, f)

				debug_log(f"OSM file saved (GeoJSON): {len(features)} features.")

			except Exception as e:
				debug_log(f"CRITICAL: Failed to process OSM data: {str(e)}")
				return

			vlayer = QgsVectorLayer(temp_geojson, "OSM", "ogr")

			if not vlayer.isValid():
				debug_log("ERROR: OSM Vector layer is invalid! Skipping terrain engineering.")
			elif vlayer.featureCount() == 0:
				debug_log("WARNING: OSM Vector layer contains 0 features! (No roads/rivers in this area). Skipping.")
			else:
				debug_log(f"SUCCESS: OSM data loaded. Total features found: {vlayer.featureCount()}")
				step_callback(82, "Rasterizing core centerlines and buffers...")

				vlayer = processing.run("native:reprojectlayer", {
					'INPUT': vlayer,
					'TARGET_CRS': target_crs,
					'OUTPUT': 'TEMPORARY_OUTPUT'
				})['OUTPUT']

				def extract_layer(expr, name):
					layer = processing.run("native:extractbyexpression", {
						'INPUT': vlayer,
						'EXPRESSION': expr,
						'OUTPUT': 'TEMPORARY_OUTPUT'
					})['OUTPUT']
					count = layer.featureCount() if layer else 0
					debug_log(f"  -> Extracted '{name}': {count} features matched.")
					return layer

				def create_buffer(layer, dist):
					if not layer or layer.featureCount() == 0:
						return None

					buf = processing.run("native:buffer", {
						'INPUT': layer,
						'DISTANCE': dist,
						'SEGMENTS': 8,
						'DISSOLVE': True,
						'OUTPUT': 'TEMPORARY_OUTPUT'
					})['OUTPUT']

					min_width = pixel_size * 1.5

					buf_fixed = processing.run("native:buffer", {
						'INPUT': buf,
						'DISTANCE': max(0.0, min_width - dist),
						'SEGMENTS': 4,
						'DISSOLVE': True,
						'OUTPUT': 'TEMPORARY_OUTPUT'
					})['OUTPUT']

					return buf_fixed

				def create_mask_from_layer(layer, file_prefix, burn_val=1):
					if not layer or layer.featureCount() == 0:
						debug_log(f"    -> Mask '{file_prefix}' is EMPTY (0 features).")
						return np.zeros((resolution_h, resolution_w), dtype=bool)

					path = os.path.join(output_dir, f"temp_{file_prefix}_{timestamp}.tif")
					created_temp_files.append(path)

					if os.path.exists(path):
						try:
							os.remove(path)
						except:
							pass

					projwin = f"{xmin},{xmax},{ymin},{ymax}"

					result = processing.run("gdal:rasterize", {
						"INPUT": layer,
						"BURN": burn_val,
						"UNITS": 0,
						"WIDTH": resolution_w,
						"HEIGHT": resolution_h,
						"EXTENT": projwin,
						"NODATA": 0,
						"DATA_TYPE": 0,
						"INIT": 0,
						"OPTIONS": "COMPRESS=LZW",
						"EXTRA": "-at",
						"OUTPUT": path
					})

					for _ in range(120):
						if os.path.exists(path) and os.path.getsize(path) > 0:
							break
						time.sleep(0.05)

					if not os.path.exists(path):
						debug_log(f"    -> ERROR: Raster file was NOT created: {path}")
						debug_log(f"    -> GDAL result: {result}")
						return np.zeros((resolution_h, resolution_w), dtype=bool)

					ds = gdal.Open(path, gdal.GA_ReadOnly)
					if ds is None:
						debug_log(f"    -> ERROR: Failed to open raster '{file_prefix}'")
						return np.zeros((resolution_h, resolution_w), dtype=bool)

					arr = ds.GetRasterBand(1).ReadAsArray()
					ds = None

					if arr.shape != (resolution_h, resolution_w):
						debug_log(f"    -> WARNING: Shape mismatch {arr.shape} -> FIX")
						fixed = np.zeros((resolution_h, resolution_w), dtype=arr.dtype)
						h = min(resolution_h, arr.shape[0])
						w = min(resolution_w, arr.shape[1])
						fixed[:h, :w] = arr[:h, :w]
						arr = fixed

					mask = arr == burn_val
					debug_log(f"    -> Mask '{file_prefix}' generated. Active pixels: {np.sum(mask)}")
					return mask

				no_bridge_tunnel = " AND (\"bridge\" IS NULL OR \"bridge\" NOT IN ('yes','true','1')) AND (\"tunnel\" IS NULL OR \"tunnel\" NOT IN ('yes','true','1'))"

				layer_heavy = extract_layer(f"\"highway\" IN ('motorway','trunk','primary','motorway_link','trunk_link','primary_link'){no_bridge_tunnel}", "Heavy Roads")
				layer_medium = extract_layer(f"\"highway\" IN ('secondary','tertiary','secondary_link','tertiary_link','residential','unclassified'){no_bridge_tunnel}", "Medium Roads")
				layer_light = extract_layer(f"\"highway\" IN ('track','path','footway','bridleway','cycleway','living_street','service'){no_bridge_tunnel}", "Light Roads")
				layer_rails = extract_layer(f"\"railway\" IS NOT NULL{no_bridge_tunnel}", "Railways")
				layer_water = extract_layer(f"\"waterway\" IS NOT NULL{no_bridge_tunnel}", "Waterways")

				# --- DYNAMIC BUFFERS USING THE MULTIPLIER ---
				BUFF_HEAVY = 12.0 * engineer_multiplier
				BUFF_MEDIUM = 6.5 * engineer_multiplier
				BUFF_LIGHT = 3.0 * engineer_multiplier
				BUFF_RAIL = 8.0 * engineer_multiplier
				BUFF_WATER = 12.0 * engineer_multiplier

				debug_log("Generating raster masks...")
				mask_heavy_b = create_mask_from_layer(create_buffer(layer_heavy, BUFF_HEAVY), "mask_h_b")
				mask_heavy_c = create_mask_from_layer(layer_heavy, "mask_h_c")

				mask_medium_b = create_mask_from_layer(create_buffer(layer_medium, BUFF_MEDIUM), "mask_m_b")
				mask_medium_c = create_mask_from_layer(layer_medium, "mask_m_c")

				mask_light_b = create_mask_from_layer(create_buffer(layer_light, BUFF_LIGHT), "mask_l_b")
				mask_light_c = create_mask_from_layer(layer_light, "mask_l_c")

				mask_rails_b = create_mask_from_layer(create_buffer(layer_rails, BUFF_RAIL), "mask_r_b")
				mask_rails_c = create_mask_from_layer(layer_rails, "mask_r_c")

				mask_water_b = create_mask_from_layer(create_buffer(layer_water, BUFF_WATER), "mask_w_b")

				step_callback(83, "Applying Spline-based Cross-flat Engineering...")
				ds_elev = gdal.Open(output_tif, gdal.GA_Update)
				elev_array = ds_elev.GetRasterBand(1).ReadAsArray().astype(np.float32)

				original_elev_array = elev_array.copy()

				def apply_flat_ribbon(current_z, center_mask, buffer_mask, sigma, falloff_dist, name):
					if not np.any(buffer_mask) or not np.any(center_mask):
						debug_log(f"Skipping ribbon '{name}' (Empty mask)")
						return current_z

					dist, indices = distance_transform_edt(~center_mask, return_indices=True)
					ribbon_z = current_z[indices[0], indices[1]]

					if sigma > 0:
						ribbon_z = gaussian_filter(ribbon_z, sigma=sigma)

					dist_inwards = distance_transform_edt(buffer_mask) * pixel_size
					falloff = np.clip(dist_inwards / falloff_dist, 0.0, 1.0)

					new_z = np.where(buffer_mask, (ribbon_z * falloff) + (current_z * (1.0 - falloff)), current_z)

					debug_log(f"Applied ribbon '{name}'. Modified pixels: {np.sum(new_z != current_z)}")
					return new_z

				elev_array = apply_flat_ribbon(elev_array, mask_light_c, mask_light_b, sigma=1.0, falloff_dist=2.0, name="Light Roads")
				elev_array = apply_flat_ribbon(elev_array, mask_medium_c, mask_medium_b, sigma=2.5, falloff_dist=4.0, name="Medium Roads")
				elev_array = apply_flat_ribbon(elev_array, mask_heavy_c, mask_heavy_b, sigma=4.0, falloff_dist=6.0, name="Heavy Roads")
				elev_array = apply_flat_ribbon(elev_array, mask_rails_c, mask_rails_b, sigma=3.5, falloff_dist=5.0, name="Railways")

				step_callback(84, "Smoothing waterways to terrain slope...")
				if np.any(mask_water_b):
					water_smooth = gaussian_filter(elev_array, sigma=4.0)
					water_target = water_smooth - 0.7
					dist_inwards_w = distance_transform_edt(mask_water_b) * pixel_size
					w_falloff = np.clip(dist_inwards_w / (BUFF_WATER * 0.5), 0.0, 1.0)

					new_elev_array = np.where(mask_water_b, (water_target * w_falloff) + (elev_array * (1.0 - w_falloff)), elev_array)

					changed_pixels = np.sum(new_elev_array != elev_array)
					elev_array = new_elev_array

					debug_log(f"Applied Waterways. Modified pixels: {changed_pixels}")
				else:
					debug_log("Skipping Waterways (Empty mask)")

				debug_log("Saving modified terrain to TIF...")
				ds_elev.GetRasterBand(1).WriteArray(elev_array)

				debug_log("Generating difference map...")
				diff_array = elev_array - original_elev_array
				diff_tif_path = os.path.join(output_dir, f"heightmap_diff_{timestamp}.tif")

				driver = gdal.GetDriverByName("GTiff")
				ds_diff = driver.Create(diff_tif_path, resolution_w, resolution_h, 1, gdal.GDT_Float32)
				ds_diff.SetGeoTransform(ds_elev.GetGeoTransform())
				ds_diff.SetProjection(ds_elev.GetProjection())
				ds_diff.GetRasterBand(1).WriteArray(diff_array)
				ds_diff.FlushCache()
				ds_diff = None
				debug_log(f"Difference map saved to: {diff_tif_path}")

				ds_elev.FlushCache()
				ds_elev = None

				debug_log("--- TERRAIN ENGINEER FINISHED ---")

		except Exception as e:
			from qgis.core import Qgis
			error_msg = f"Terrain smoothing failed with Exception: {e}"
			debug_log(f"CRITICAL ERROR: {error_msg}")
			self.iface.messageBar().pushMessage(
				"Engineering Warn",
				error_msg,
				level=Qgis.Warning,
				duration=5
			)

		finally:
			for temp_file in created_temp_files:
				try:
					if os.path.exists(temp_file):
						os.remove(temp_file)
				except:
					pass

class ArmaExportPlugin:
	def __init__(self, iface):
		self.iface = iface
		self.action = None
		self.custom_menu = None
		self.plugin_dir = os.path.dirname(__file__)

	def initGui(self):
		if globals().get('GITHUB_USER') and globals().get('GITHUB_REPO') and "YOU_REPOD" not in GITHUB_REPO:
			self.register_github_repository()

		icon_path = os.path.join(self.plugin_dir, 'icon.png')
		if os.path.exists(icon_path):
			self.action = QAction(QIcon(icon_path), "ARTE - Arma Reforger Terrain Exporter", self.iface.mainWindow())
		else:
			self.action = QAction("ARTE - Arma Reforger Terrain Exporter", self.iface.mainWindow())

		self.action.triggered.connect(self.run)
		self.iface.addRasterToolBarIcon(self.action)

		menu_bar = self.iface.mainWindow().menuBar()
		self.custom_menu = menu_bar.findChild(QMenu, "ArmaToolsMenu")
		if not self.custom_menu:
			self.custom_menu = QMenu("Arma Tools (ARTE)", menu_bar)
			self.custom_menu.setObjectName("ArmaToolsMenu")
			menu_bar.addMenu(self.custom_menu)

		self.custom_menu.addAction(self.action)

	def register_github_repository(self):
		try:
			from qgis.core import QgsSettings
			settings = QgsSettings()

			settings.beginGroup("app/plugin_repositories")
			repos = settings.childGroups()
			settings.endGroup()

			repo_name = "Arma Reforger ARTE Repository"
			repo_url = f"https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/main/plugins.xml"

			already_exists = False

			for r in repos:
				if r.startswith("arma_auto_repo_"):
					url = settings.value(f"app/plugin_repositories/{r}/url")

					if url == repo_url and "YOU_REPOD" not in repo_url:
						already_exists = True
					else:
						settings.remove(f"app/plugin_repositories/{r}")

			if not already_exists and globals().get('GITHUB_USER') and globals().get('GITHUB_REPO') and "YOU_REPOD" not in GITHUB_REPO:
				internal_id = f"arma_auto_repo_{int(time.time())}"

				settings.setValue(f"app/plugin_repositories/{internal_id}/name", repo_name)
				settings.setValue(f"app/plugin_repositories/{internal_id}/url", repo_url)
				settings.setValue(f"app/plugin_repositories/{internal_id}/enabled", True)
				settings.setValue(f"app/plugin_repositories/{internal_id}/valid", True)

				self.iface.messageBar().pushMessage(
					"Repository Config",
					"Arma Official Update Stream has been automatically linked!",
					level=Qgis.Success,
					duration=4
				)
		except Exception:
			pass

	def unload(self):
		if self.action:
			self.iface.removeRasterToolBarIcon(self.action)
			if self.custom_menu:
				self.custom_menu.removeAction(self.action)
				if not self.custom_menu.actions():
					menu_bar = self.iface.mainWindow().menuBar()
					menu_bar.removeAction(self.custom_menu.menuAction())

		try:
			from qgis.core import QgsSettings
			settings = QgsSettings()

			settings.beginGroup("app/plugin_repositories")
			repos = settings.childGroups()
			settings.endGroup()

			for r in repos:
				if r.startswith("arma_auto_repo_"):
					settings.remove(f"app/plugin_repositories/{r}")
		except Exception:
			pass

	def check_for_updates(self):
		try:
			if not globals().get('GITHUB_USER') or not globals().get('GITHUB_REPO') or "YOU_REPOD" in GITHUB_REPO:
				return

			url = f"https://api.github.com/repos/{GITHUB_USER}/{GITHUB_REPO}/releases/latest"
			req = urllib.request.Request(url, headers={'User-Agent': 'QGIS-Arma-Plugin-Updater'})

			with urllib.request.urlopen(req, timeout=2.0) as response:
				data = json.loads(response.read().decode('utf-8'))
				latest_version = data['tag_name'].replace('v', '')
				release_url = data['html_url']

				current_v = tuple(map(int, VERSION.split('.')))
				latest_v = tuple(map(int, latest_version.split('.')))

				if latest_v > current_v:
					msg = QMessageBox()
					msg.setIcon(QMessageBox.Information if not hasattr(QMessageBox, 'StandardButton') else QMessageBox.Information)
					msg.setWindowTitle("ARTE - Update Available")
					msg.setText(f"A new version of ARTE (Arma Reforger Terrain Exporter) is available!\n\nCurrent: v{VERSION}\nNew: v{latest_version}")
					msg.setInformativeText("Would you like to open the GitHub download page?")
					msg.setStandardButtons(QM_Yes | QM_No)

					if msg.exec() == QM_Yes:
						QDesktopServices.openUrl(QUrl(release_url))
		except Exception:
			pass

	def run(self):
		self.check_for_updates()

		self.dialog = CombinedArmaInputDialog(self.iface.mainWindow())
		self.dialog.accepted.connect(lambda: self.execute_export(self.dialog))
		self.dialog.show()

	def execute_export(self, dialog):
		from qgis.core import QgsSettings, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsPointXY, QgsRectangle, QgsRasterLayer, QgsMapSettings, QgsMapRendererSequentialJob

		x_center = dialog.sb_x.value()
		y_center = dialog.sb_y.value()
		size_w = dialog.sb_size_w.value()
		size_h = dialog.sb_size_h.value()

		resolution_w = dialog.sb_res_w.value()
		resolution_h = dialog.sb_res_h.value()
		sat_res_w = dialog.sb_sat_res_w.value()
		sat_res_h = dialog.sb_sat_res_h.value()

		output_dir = dialog.le_path.text()
		format_index = dialog.cb_format.currentIndex()

		want_burn = dialog.cb_burn_terrain.isChecked() if hasattr(dialog, 'cb_burn_terrain') else False

		source_idx = dialog.cb_source.currentIndex()
		api_key = dialog.le_apikey.text().strip()
		ot_dem_type = dialog.cb_ot_type.currentData()

		settings = QgsSettings()
		settings.setValue("ArmaReforgerTools/mapbox_api_key", dialog.mapbox_key)
		settings.setValue("ArmaReforgerTools/ot_api_key", dialog.ot_key)

		if (source_idx == 1 or source_idx == 2) and not api_key:
			QMessageBox.warning(self.iface.mainWindow(), "Warning", "An API key is required to use the selected source!")
			return

		if source_idx == 2:
			max_allowed_size = 25000
			if size_w > max_allowed_size or size_h > max_allowed_size:
				QMessageBox.warning(
					self.iface.mainWindow(),
					"Too Large Area",
					f"OpenTopography API limits the data download size.\n\n"
					f"Your current selection is {size_w}m x {size_h}m.\n"
					f"Please reduce the 'Size (meters)' below {max_allowed_size}m (25km),\n"
					f"otherwise the server will return an HTTP 400 Error."
				)
				return

		want_png = format_index == 0
		want_asc = format_index == 1
		want_tif = format_index == 2

		gdal_alg = gdal.GRA_Lanczos

		valasz = QMessageBox.question(
			self.iface.mainWindow(),
			"Confirmation",
			f"Start Enfusion export?\n\nSize: {size_w}x{size_h}m\nHeightmap: {resolution_w}x{resolution_h}px\nSatellite: {sat_res_w}x{sat_res_h}px\nPath: {output_dir}",
			QM_Yes | QM_No
		)

		if valasz != QM_Yes:
			return

		try:
			if not os.path.exists(output_dir):
				os.makedirs(output_dir)
		except Exception as e:
			QMessageBox.critical(self.iface.mainWindow(), "Error", f"Could not create directory {output_dir}: {e}")
			return

		timestamp = time.strftime("%Y%m%d_%H%M%S")
		output_sat_png = os.path.join(output_dir, f"satmap_{timestamp}.png")
		output_tif = os.path.join(output_dir, f"heightmap_{timestamp}.tif")
		output_asc = os.path.join(output_dir, f"heightmap_{timestamp}.asc")
		output_png = os.path.join(output_dir, f"heightmap_{timestamp}.png")
		output_txt = os.path.join(output_dir, f"enfusion_import_{timestamp}.txt")
		temp_rgb_tif = os.path.join(output_dir, f"temp_terrarium_{timestamp}.tif")

		progress = QProgressDialog("Export running...", "Cancel", 0, 100, self.iface.mainWindow())
		progress.setWindowTitle("Enfusion Export Status")
		progress.show()

		def step(val, text):
			progress.setValue(val)
			progress.setLabelText(text)
			QApplication.processEvents()
			if progress.wasCanceled():
				raise Exception("Export cancelled by user.")

		google_layer = None

		try:
			step(5, "Transforming coordinates with correction...")
			lat_rad = math.radians(y_center)
			scale_factor = 1.0 / math.cos(lat_rad)
			corrected_size_w = size_w * scale_factor
			corrected_size_h = size_h * scale_factor

			source_crs = QgsCoordinateReferenceSystem("EPSG:4326")
			target_crs = QgsCoordinateReferenceSystem("EPSG:3857")
			context = QgsProject.instance().transformContext()
			transform = QgsCoordinateTransform(source_crs, target_crs, context)
			pt = transform.transform(QgsPointXY(x_center, y_center))

			half_w = corrected_size_w / 2
			half_h = corrected_size_h / 2
			rect = QgsRectangle(pt.x() - half_w, pt.y() - half_h, pt.x() + half_w, pt.y() + half_h)

			for layer in list(QgsProject.instance().mapLayers().values()):
				if "Google_Sat_" in layer.name() or "DEM_Source_" in layer.name() or "AWS_Terrarium_" in layer.name():
					QgsProject.instance().removeMapLayer(layer.id())
			gc.collect()
			QApplication.processEvents()

			# 1. PHASE: Satellite Image
			step(15, "Downloading Google Satellite imagery...")
			uri = "type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D&zmax=19&zmin=0"
			google_layer = QgsRasterLayer(uri, f"Google_Sat_{timestamp}", "wms")
			QgsProject.instance().addMapLayer(google_layer)
			QApplication.processEvents()

			step(30, "Rendering satellite image...")
			settings_sat = QgsMapSettings()
			settings_sat.setLayers([google_layer])
			settings_sat.setBackgroundColor(QColor(255, 255, 255))

			settings_sat.setOutputSize(QSize(sat_res_w, sat_res_h))
			settings_sat.setExtent(rect)

			job_sat = QgsMapRendererSequentialJob(settings_sat)
			job_sat.start()
			job_sat.waitForFinished()
			job_sat.renderedImage().save(output_sat_png)

			QgsProject.instance().removeMapLayer(google_layer.id())
			google_layer = None
			job_sat = None
			settings_sat = None
			gc.collect()

			# 2. PHASE: Heightmap Prep
			step(45, "Calculating raw heightmap tile coordinates...")
			xmin, ymin, xmax, ymax = rect.xMinimum(), rect.yMinimum(), rect.xMaximum(), rect.yMaximum()

			def epsg3857_to_tile(x, y, z):
				origin_shift = 20037508.342789244
				res = (origin_shift * 2.0) / (256.0 * (2.0**z))
				px = (x + origin_shift) / res
				py = (origin_shift - y) / res
				tx = int(px // 256)
				ty = int(py // 256)
				return tx, ty, px, py

			target_mpp = corrected_size_w / resolution_w
			earth_circ = 20037508.342789244 * 2.0
			z_float = math.log2(earth_circ / (256.0 * target_mpp))
			z = int(math.ceil(z_float))
			z = max(0, min(z, 15))

			txmin, tymin, pxmin, pymin = epsg3857_to_tile(xmin, ymax, z)
			txmax, tymax, pxmax, pymax = epsg3857_to_tile(xmax, ymin, z)

			tiles_wide = txmax - txmin + 1
			tiles_high = tymax - tymin + 1
			total_tiles = tiles_wide * tiles_high

			if total_tiles > 1024:
				z -= 1
				txmin, tymin, pxmin, pymin = epsg3857_to_tile(xmin, ymax, z)
				txmax, tymax, pxmax, pymax = epsg3857_to_tile(xmax, ymin, z)
				tiles_wide = txmax - txmin + 1
				tiles_high = tymax - tymin + 1
				total_tiles = tiles_wide * tiles_high

			if source_idx == 0 or source_idx == 1:
				full_image = np.zeros((tiles_high * 256, tiles_wide * 256, 3), dtype=np.uint8)

				tile_idx = 0
				for tx in range(txmin, txmax + 1):
					for ty in range(tymin, tymax + 1):
						if progress.wasCanceled():
							raise Exception("Export cancelled by user.")
						step(50 + int(20 * (tile_idx / total_tiles)), f"Downloading raw DEM tiles {tile_idx+1}/{total_tiles}...")

						if source_idx == 0:
							url = f"https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{tx}/{ty}.png"
						elif source_idx == 1:
							url = f"https://api.mapbox.com/v4/mapbox.terrain-rgb/{z}/{tx}/{ty}.png?access_token={api_key}"

						try:
							req = urllib.request.Request(url, headers={'User-Agent': 'QGIS-Arma-Plugin/1.0'})
							with urllib.request.urlopen(req) as response:
								img = Image.open(response).convert('RGB')
								y_off = (ty - tymin) * 256
								x_off = (tx - txmin) * 256
								full_image[y_off:y_off+256, x_off:x_off+256, :] = np.array(img)
						except Exception as e:
							pass
						tile_idx += 1

				step(75, "Decoding pure RGB channels to continuous float elevation...")
				crop_x1 = int(max(0, round(pxmin - txmin * 256)))
				crop_y1 = int(max(0, round(pymin - tymin * 256)))
				crop_x2 = int(min(full_image.shape[1], round(pxmax - txmin * 256)))
				crop_y2 = int(min(full_image.shape[0], round(pymax - tymin * 256)))

				crop_array = full_image[crop_y1:crop_y2, crop_x1:crop_x2, :]

				r = crop_array[:, :, 0].astype(np.float32)
				g = crop_array[:, :, 1].astype(np.float32)
				b = crop_array[:, :, 2].astype(np.float32)

				if source_idx == 0:
					elevation = (r * 256.0 + g + (b / 256.0)) - 32768.0
				else:
					elevation = -10000.0 + (r * 65536.0 + g * 256.0 + b) * 0.1

				step(80, "Smooth scaling to requested resolution...")
				driver_mem = gdal.GetDriverByName('MEM')
				ds_mem = driver_mem.Create('', elevation.shape[1], elevation.shape[0], 1, gdal.GDT_Float32)

				pixel_size_x = (xmax - xmin) / elevation.shape[1]
				pixel_size_y = (ymax - ymin) / elevation.shape[0]

				ds_mem.SetGeoTransform((xmin, pixel_size_x, 0, ymax, 0, -pixel_size_y))
				srs = osr.SpatialReference()
				srs.ImportFromEPSG(3857)
				ds_mem.SetProjection(srs.ExportToWkt())
				ds_mem.GetRasterBand(1).WriteArray(elevation)

				gdal.Warp(output_tif, ds_mem,
						  width=resolution_w, height=resolution_h,
						  outputBounds=(xmin, ymin, xmax, ymax),
						  resampleAlg=gdal_alg,
						  outputType=gdal.GDT_Float32,
						  format='GTiff')

				ds_mem = None

			elif source_idx == 2:
				step(50, "Downloading OpenTopography DEM via API...")
				context = QgsProject.instance().transformContext()
				transform_to_4326 = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:3857"), QgsCoordinateReferenceSystem("EPSG:4326"), context)
				pt_min = transform_to_4326.transform(QgsPointXY(xmin, ymin))
				pt_max = transform_to_4326.transform(QgsPointXY(xmax, ymax))

				south = min(pt_min.y(), pt_max.y())
				north = max(pt_min.y(), pt_max.y())
				west = min(pt_min.x(), pt_max.x())
				east = max(pt_min.x(), pt_max.x())

				url = f"https://portal.opentopography.org/API/globaldem?demtype={ot_dem_type}&south={south}&north={north}&west={west}&east={east}&outputFormat=GTiff&API_Key={api_key}"

				req = urllib.request.Request(url, headers={'User-Agent': 'QGIS-Arma-Plugin/1.0'})
				try:
					with urllib.request.urlopen(req) as response:
						with open(temp_rgb_tif, 'wb') as f:
							f.write(response.read())
				except urllib.error.HTTPError as http_err:
					try:
						server_response = http_err.read().decode('utf-8')

						clean_error = server_response
						if "<error>" in server_response and "</error>" in server_response:
							clean_error = server_response.split("<error>")[1].split("</error>")[0]

						if "maximum rate limit" in clean_error.lower():
							error_details = (
								"You have hit the anonymous rate limit (50 requests / 24 hours).\n\n"
								"HOW TO FIX THIS:\n"
								"1. Sign up for a free account at portal.opentopography.org\n"
								"2. Generate your personal API Key (Go to: myOT > myOT API Key)\n"
								"3. Paste your key into the 'API Key' field in this plugin to continue!"
							)
						elif "invalid api key" in clean_error.lower():
							error_details = "The provided API Key is invalid. Please double-check your key for typos!"
						elif "bad request" in clean_error.lower():
							error_details = "Bad Request. Your selected coordinates or bounding box format might be wrong."
						else:
							error_details = f"Server Response: {clean_error}"
					except:
						error_details = f"HTTP Error Code: {http_err.code}"
					raise Exception(f"OpenTopography API rejected your request!\n\n{error_details}")
				except Exception as e:
					raise Exception(f"Connection error to OpenTopography: {e}")

				step(80, "Smooth scaling to requested resolution...")
				gdal.Warp(output_tif, temp_rgb_tif,
						  width=resolution_w, height=resolution_h,
						  outputBounds=(xmin, ymin, xmax, ymax),
						  dstSRS='EPSG:3857',
						  resampleAlg=gdal_alg,
						  outputType=gdal.GDT_Float32,
						  format='GTiff')


			# =========================================================================
			# TERRAIN ENGINEERING
			# =========================================================================
			if want_burn:
				engineer = TerrainEngineer(self.iface)
				engineer.run(
					output_tif=output_tif,
					output_dir=output_dir,
					timestamp=timestamp,
					xmin=xmin, ymin=ymin, xmax=xmax, ymax=ymax,
					resolution_w=resolution_w,
					resolution_h=resolution_h,
					target_crs=target_crs,
					source_crs=source_crs,
					context=context,
					pixel_size=(xmax - xmin) / resolution_w,
					step_callback=step
				)
			# =========================================================================

			step(85, "Applying Enfusion specific corrections...")
			ds_out = gdal.Open(output_tif, gdal.GA_Update)
			elevation_resampled = ds_out.GetRasterBand(1).ReadAsArray()

			valid_mask = elevation_resampled > -10000.0
			if np.any(valid_mask):
				min_val = float(np.min(elevation_resampled[valid_mask]))
				max_val = float(np.max(elevation_resampled[valid_mask]))
				elevation_resampled = np.where(valid_mask, elevation_resampled, min_val)
			else:
				min_val = float(np.min(elevation_resampled))
				max_val = float(np.max(elevation_resampled))

			ds_out.GetRasterBand(1).WriteArray(elevation_resampled)
			ds_out.FlushCache()

			orig_min = min_val
			orig_max = max_val

			grid_cell_size = size_w / resolution_w
			height_scale = (max_val - min_val) / 65535.0 if max_val > min_val else 1.0

			with open(output_txt, "w", encoding="utf-8") as txt_f:
				txt_f.write("=== Arma Reforger / Enfusion Import Values ===\n\n")
				txt_f.write(f"Grid cell size (meters): {grid_cell_size:.4f}\n")
				txt_f.write(f"Height scale (meters): {height_scale:.6f}\n")
				txt_f.write(f"Terrain grid size: {resolution_w}x{resolution_h}\n\n")
				txt_f.write(f"--- Debug Info ---\n")
				txt_f.write(f"Original Min Elev: {orig_min:.2f} m\n")
				txt_f.write(f"Original Max Elev: {orig_max:.2f} m\n")

			if want_asc:
				driver_asc = gdal.GetDriverByName('AAIGrid')
				ds_asc = driver_asc.CreateCopy(output_asc, ds_out)
				ds_asc = None

			if want_png:
				step(95, "Generating high-fidelity 16-bit PNG...")
				if max_val > min_val:
					elevation_16bit = (((elevation_resampled - min_val) / (max_val - min_val)) * 65535.0)
				else:
					elevation_16bit = np.zeros_like(elevation_resampled)

				elevation_16bit = np.clip(elevation_16bit, 0, 65535).astype(np.uint16)

				driver_mem_16 = gdal.GetDriverByName('MEM')
				ds_mem_16 = driver_mem_16.Create('', resolution_w, resolution_h, 1, gdal.GDT_UInt16)
				ds_mem_16.GetRasterBand(1).WriteArray(elevation_16bit)

				driver_png = gdal.GetDriverByName('PNG')
				driver_png.CreateCopy(output_png, ds_mem_16)
				ds_mem_16 = None

			ds_out = None

			if not want_tif:
				try: os.remove(output_tif)
				except: pass

			step(100, "Done!")
			progress.close()

			success_msg = f"All Enfusion files exported to:\n{output_dir}!\n\n"
			success_msg += f"1. Satmap: satmap_{timestamp}.png ({sat_res_w}x{sat_res_h})\n"
			success_msg += f"2. Enfusion Values: enfusion_import_{timestamp}.txt\n"
			if want_tif: success_msg += f"3. Heightmap TIF: heightmap_{timestamp}.tif ({resolution_w}x{resolution_h})\n"
			if want_asc: success_msg += f"3. Heightmap ASC: heightmap_{timestamp}.asc ({resolution_w}x{resolution_h})\n"
			if want_png: success_msg += f"3. Heightmap 16-bit PNG: heightmap_{timestamp}.png ({resolution_w}x{resolution_h})\n"
			success_msg += f"\nMin Elev: {min_val:.2f}m\nMax Elev: {max_val:.2f}m\n"

			QMessageBox.information(self.iface.mainWindow(), "Success", success_msg)

		except Exception as e:
			QMessageBox.critical(self.iface.mainWindow(), "Error", str(e))
		finally:
			progress.close()
			try:
				if os.path.exists(temp_rgb_tif):
					os.remove(temp_rgb_tif)
			except:
				pass
			gc.collect()